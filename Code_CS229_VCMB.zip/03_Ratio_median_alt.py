# %%
import pandas as pd
from sklearn.ensemble import RandomForestRegressor
from sklearn.model_selection import train_test_split, GridSearchCV
from sklearn.metrics import mean_squared_error, r2_score
import numpy as np
import joblib
import openpyxl



# %%
import matplotlib.pyplot as plt

# %% [markdown]
# # 00 General + functions

# %%
# INPUT 1/4
model_input = 'Log_periods'
model_target = 'Ratio_median'
x_label = model_input
y_label = "Sa_RotD100/Sa_RotD50"
title = f"Ratio of {y_label} vs {x_label}"

# %%
# Load the pickled DataFrame
df_dataset = pd.read_pickle(f'datasets/working_df.pkl')[[model_input, model_target]]

min_value = df_dataset[model_input].min()
max_value = df_dataset[model_input].max()

df_dataset

# %%
# Define features and target
X = df_dataset[[model_input]]  # Features
y = df_dataset[model_target]    # Target

# Split into train and test sets
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# %% [markdown]
# ## 0.1 Functions

# %%
def hyperparameter_selection(X_train, y_train, model, param_grid, model_name, model_target):
    # Initialize GridSearchCV
    grid_search = GridSearchCV(estimator=model, param_grid=param_grid, cv=10, scoring='neg_mean_squared_error')

    # Fit the model
    grid_search.fit(X_train, y_train)

    # Get the best parameters and score
    best_params = grid_search.best_params_
    best_score = grid_search.best_score_

    print("Best Parameters:", best_params)
    print("Best Cross-Validated MSE Score:", best_score)

    # Evaluate on the test set
    best_model = grid_search.best_estimator_

    # Save the model to a .pkl file
    joblib.dump(best_model, f'models/{model_name}_{model_target}.pkl')
    print(f"Model saved as {model_name}_{model_target}.pkl")

    # Extract cross-validation results
    cv_results = grid_search.cv_results_

    # Create a DataFrame to store the results
    results_df = pd.DataFrame({
        'hyperparameters': cv_results['params'],
        'mean MSE': cv_results['mean_test_score'],
        'std': cv_results['std_test_score']
    })

    # Save the DataFrame to an Excel file
    excel_filename = f'models/{model_name}_{model_target}_results.xlsx'
    results_df.to_excel(excel_filename, index=False)
    print(f"Cross-validation results saved to {excel_filename}")

# %%
def plot_actual_prediction(best_model):
    # Scatter plot for the actual data
    plt.scatter(X_test, y_test, label="Testing Data", color="blue", alpha=0.7)

    # Generate predictions across the range of Periods (min to max)
    X_line = np.linspace(min_value, max_value, 500).reshape(-1, 1)
    y_line_pred = best_model.predict(X_line)

    # Plot the line for predictions
    plt.plot(X_line, y_line_pred, label="Model Prediction", color="red", linewidth=2)

    # Add labels, legend, and title
    plt.xlabel(x_label)
    plt.ylabel(y_label)
    plt.title(title)
    plt.legend()
    plt.grid(True)

    # Show the plot
    plt.show()

# %%
def plot_hyperparameters_set(model_name, model_target):
    # 1. Load the Excel file
    excel_filename = f'models/{model_name}_{model_target}_results.xlsx'
    results_df = pd.read_excel(excel_filename)

    # 2. Sort the hyperparameters based on the mean MSE in descending order
    sorted_results = results_df.sort_values(by='mean MSE', ascending=False)

    # Step 3: Plot descending the hyperparameters based on the mean MSE
    plt.figure(figsize=(12, 6))
    plt.plot(sorted_results['mean MSE'].values)
    plt.title(f'Hyperparameters Sorted by Mean MSE for {model_name}')
    plt.xlabel('Hyperparameter Set Index')
    plt.ylabel('Negative Mean MSE')
    plt.show()

    # Step 4: Extract the top 10 hyperparameter sets
    top_10 = sorted_results.head(10)

    # Display the top 10 hyperparameter sets with mean test score
    print(f"Top 10 Hyperparameter Sets Based on Mean negative MSE for {model_name}:")
    print(top_10[['hyperparameters', 'mean MSE', 'std']])

# %% [markdown]
# # 01 Random Forest

# %%
# INPUT 2/4
# Model
model_name = 'Random_Forest'

# INPUT 3/4
mode = 1

# modes
# 0: training the model
# 1: loading the model

# %%
# INPUT 4/4
if not mode:
    # Define the model
    rf = RandomForestRegressor(random_state=42)

    # Define the parameter grid
    param_grid = {
        'n_estimators': [50, 100, 200, 500],  # Number of trees in the forest
        'criterion': ["squared_error", "absolute_error", "friedman_mse", "poisson"],
        'max_depth': [None, 10, 20, 30, 50],  # Maximum depth of the tree
        'min_samples_split': [2, 5, 10],  # Minimum number of samples required to split an internal node
        'min_samples_leaf': [1, 2, 4],  # Minimum number of samples required to be at a leaf node
        'max_features': ['sqrt', 'log2'],  # Number of features to consider when looking for the best split
    }

    hyperparameter_selection(X_train, y_train, rf, param_grid, model_name, model_target)

# %%
# Load the model from the .pkl file
best_model = joblib.load(f'models/{model_name}_{model_target}.pkl')

y_pred = best_model.predict(X_test)

# Calculate performance metrics
mse = mean_squared_error(y_test, y_pred)
r2 = r2_score(y_test, y_pred)

print("Test MSE:", mse)
print("Test R2 Score:", r2)

# %%
plot_actual_prediction(best_model)

# %%
plot_hyperparameters_set(model_name, model_target)

# %% [markdown]
# # 02 SVM


